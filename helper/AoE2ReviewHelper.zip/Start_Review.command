#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
clear
echo "=================================================="
echo "  AoE2 Replay Chronicle - Camera Companion"
echo "=================================================="
echo ""

HELPER_PY=""
if [ -f "$DIR/AoE2ReviewHelper.app/Contents/Resources/helper.py" ]; then
    HELPER_PY="$DIR/AoE2ReviewHelper.app/Contents/Resources/helper.py"
elif [ -f "$DIR/helper.py" ]; then
    HELPER_PY="$DIR/helper.py"
fi

if [ -z "$HELPER_PY" ]; then
    echo "Error: helper.py could not be found."
    echo "Please ensure Start_Review.command is kept next to AoE2ReviewHelper.app."
    echo ""
    echo "Press Enter to exit..."
    read -r
    exit 1
fi

python3 "$HELPER_PY" "$@"
STATUS=$?

echo ""
if [ $STATUS -eq 0 ]; then
    echo "Camera Director finished successfully."
else
    echo "Camera Director stopped."
fi
echo "Press Enter to close this window..."
read -r
